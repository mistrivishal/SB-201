package com.masai.dao;

import java.util.List;

import com.masai.model.Product;


public interface ProductDao {
	
	public Boolean insertProduct(Product p);

	public List<Product> getAllProducts();

	public Product getProductById(int pId);

	public Boolean deleteProduct(int pId);
;
}
