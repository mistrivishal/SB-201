package com.masai.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.stereotype.Service;


@Service
public class UtilEntity {
	
	public static EntityManagerFactory emf = Persistence.createEntityManagerFactory("products-unit");
	
	
	public static EntityManager getEntityManager() {
		
		return emf.createEntityManager();
	}

}
