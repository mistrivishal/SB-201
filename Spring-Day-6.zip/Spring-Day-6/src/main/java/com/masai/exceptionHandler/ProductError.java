package com.masai.exceptionHandler;

public class ProductError extends RuntimeException{
	
	public ProductError (){
		
	}
	
	public ProductError (String s){
		super(s);
	}
}
