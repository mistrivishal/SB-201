package com.masai.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.masai.model.Product;
import com.masai.seviceLayer.productsSL;

@RestController
public class ProductController {

	@Autowired
	public static productsSL psl = new productsSL();

	@GetMapping("/products")
	public static List<Product> getAllProducts() {

		return psl.getProducts();

	}

	@GetMapping("/product/{id}")
	public Product getProductDetails(@PathVariable int id) {

		return psl.getProductByID(id);
	}
	
	@PostMapping("/pro")
	public String saveProductDetails(@RequestBody Product p) {
		
		return psl.addProduct(p);
	}
	
	
}
