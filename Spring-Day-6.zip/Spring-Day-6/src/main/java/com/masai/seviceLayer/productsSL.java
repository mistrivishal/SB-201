package com.masai.seviceLayer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.masai.dao.ProductDao;
import com.masai.dataAccessLayer.ProductDaoImpl;
import com.masai.exceptionHandler.InvalidProductId;
import com.masai.exceptionHandler.ProductError;
import com.masai.model.Product;


@Service
public class productsSL {
	
	public static ProductDao pDao = new ProductDaoImpl();
	
	@Autowired
	public static ResponseEntity<String> re;

	public List<Product> getProducts() {

		return pDao.getAllProducts();
	}

	public Product getProductByID(int id) {

		Product p = pDao.getProductById(id);

		if (p != null) {
			return p;
		} else {
			throw new InvalidProductId("Invalid Product ID" + id);
		}
	}
	
	public String addProduct(Product p) {
		
		Boolean b = pDao.insertProduct(p);
		if(b) {
			return "Product Stored";
		}else {
			throw new ProductError("Product Not Acceptable");
		}
	}
	
	public Boolean deleteProduct(int pId) {
		
		return pDao.deleteProduct(pId);
	}
}

//public static List<Product> products = Arrays.asList(
//
//		new Product(101, "Nokia_101", 20000.00, "Nokia", "Mobile", "N101", "NK101"),
//		new Product(102, "Note_9", 22500.00, "Samsung", "Moblie", "S102", "SAM102"),
//		new Product(103, "Oneplus_9", 33000.00, "One_Plus", "Mobile", "One103", "O103"),
//		new Product(104, "Smasung_Tab_3", 19000.00, "Samsung", "Tablet", "S104", "SAMT104"));