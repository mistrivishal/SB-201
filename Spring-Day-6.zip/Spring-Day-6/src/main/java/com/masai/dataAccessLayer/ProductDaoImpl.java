package com.masai.dataAccessLayer;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Service;

import com.masai.dao.ProductDao;
import com.masai.dao.UtilEntity;
import com.masai.model.Product;

@Service
public class ProductDaoImpl implements ProductDao {

	private static EntityManager em = UtilEntity.getEntityManager();

	@Override
	public Boolean insertProduct(Product p) {
		
		Boolean b = false;

		System.out.println(p);
		
		if (p != null) {
			em.getTransaction().begin();

			em.persist(p);

			b = true;

			em.getTransaction().commit();
		}

		return b;
	}

	@Override
	public List<Product> getAllProducts() {

		return em.createQuery("From Product", Product.class).getResultList();
	}

	@Override
	public Product getProductById(int pId) {

		return em.find(Product.class, pId);
	}

	@Override
	public Boolean deleteProduct(int pId) {

		Boolean b = false;

		Product p = em.find(Product.class, pId);

		if (p != null) {
			em.getTransaction().begin();

			em.remove(p);

			b = true;

			em.getTransaction().commit();
		}

		return b;
	}

}
