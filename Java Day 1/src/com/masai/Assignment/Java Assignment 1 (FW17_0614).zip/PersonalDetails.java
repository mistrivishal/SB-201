public class PersonalDetails{

	public static void main(String[] args){
	
		System.out.println("Name : Vishal");
		System.out.println("Father's Name : Dattatreya");
		System.out.println("Mother's Name : Aruna");
		System.out.println("Age : 26");
		System.out.println("Gender : Male");
		System.out.println("Address : Somewhere on the earth..!");
		System.out.println("Mobile No. : 9999988888");

	}
}